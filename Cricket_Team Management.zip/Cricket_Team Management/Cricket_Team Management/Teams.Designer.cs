﻿namespace Cricket_Team_Management
{
    partial class Teams
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbldisplay = new System.Windows.Forms.Label();
            this.lbldelete = new System.Windows.Forms.Label();
            this.lbladd = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbldisplay
            // 
            this.lbldisplay.AutoSize = true;
            this.lbldisplay.Location = new System.Drawing.Point(41, 141);
            this.lbldisplay.Name = "lbldisplay";
            this.lbldisplay.Size = new System.Drawing.Size(116, 17);
            this.lbldisplay.TabIndex = 5;
            this.lbldisplay.Text = "DISPLAY TEAMS";
            this.lbldisplay.Click += new System.EventHandler(this.lbldisplay_Click);
            // 
            // lbldelete
            // 
            this.lbldelete.AutoSize = true;
            this.lbldelete.Location = new System.Drawing.Point(41, 92);
            this.lbldelete.Name = "lbldelete";
            this.lbldelete.Size = new System.Drawing.Size(113, 17);
            this.lbldelete.TabIndex = 4;
            this.lbldelete.Text = "DELETE TEAMS";
            this.lbldelete.Click += new System.EventHandler(this.lbldelete_Click);
            // 
            // lbladd
            // 
            this.lbladd.AutoSize = true;
            this.lbladd.Location = new System.Drawing.Point(41, 48);
            this.lbladd.Name = "lbladd";
            this.lbladd.Size = new System.Drawing.Size(88, 17);
            this.lbladd.TabIndex = 3;
            this.lbladd.Text = "ADD TEAMS";
            this.lbladd.Click += new System.EventHandler(this.lbladd_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 191);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "UPDATE TEAMS";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 241);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "SEARCH TEAMS";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Teams
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbldisplay);
            this.Controls.Add(this.lbldelete);
            this.Controls.Add(this.lbladd);
            this.Name = "Teams";
            this.Text = "Teams";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbldisplay;
        private System.Windows.Forms.Label lbldelete;
        private System.Windows.Forms.Label lbladd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}