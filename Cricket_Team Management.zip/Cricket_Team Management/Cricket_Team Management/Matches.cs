﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Matches : Form
    {
        public Matches()
        {
            InitializeComponent();
        }

        private void lbladd_Click(object sender, EventArgs e)
        {
            Add_Matches ob = new Add_Matches();
            ob.Show();
            this.Hide();
        }

        private void lbldelete_Click(object sender, EventArgs e)
        {
            Delete_Matches ob = new Delete_Matches();
            ob.Show();
            this.Hide();
        }

        private void lbldisplay_Click(object sender, EventArgs e)
        {
            Display_Matches ob = new Display_Matches();
            ob.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Update_Matches ob = new Update_Matches();
            ob.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Search_Matches ob = new Search_Matches();
            ob.Show();
            this.Hide();

        }
    }
}
