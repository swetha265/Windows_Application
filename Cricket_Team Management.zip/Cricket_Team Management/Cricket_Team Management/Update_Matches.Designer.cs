﻿namespace Cricket_Team_Management
{
    partial class Update_Matches
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.txttid = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.panel = new System.Windows.Forms.Panel();
            this.txtstadium = new System.Windows.Forms.TextBox();
            this.dtmatch = new System.Windows.Forms.DateTimePicker();
            this.txtt2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.txtt1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.txttid)).BeginInit();
            this.panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(779, 62);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(181, 27);
            this.button1.TabIndex = 5;
            this.button1.Text = "SEARCH ID";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txttid
            // 
            this.txttid.Location = new System.Drawing.Point(364, 62);
            this.txttid.Name = "txttid";
            this.txttid.Size = new System.Drawing.Size(224, 22);
            this.txttid.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(82, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "ENTER MATCH ID";
            // 
            // panel
            // 
            this.panel.Controls.Add(this.txtstadium);
            this.panel.Controls.Add(this.dtmatch);
            this.panel.Controls.Add(this.txtt2);
            this.panel.Controls.Add(this.label3);
            this.panel.Controls.Add(this.label2);
            this.panel.Controls.Add(this.label4);
            this.panel.Controls.Add(this.btnsubmit);
            this.panel.Controls.Add(this.txtt1);
            this.panel.Controls.Add(this.label5);
            this.panel.Location = new System.Drawing.Point(85, 124);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(875, 436);
            this.panel.TabIndex = 6;
            // 
            // txtstadium
            // 
            this.txtstadium.Location = new System.Drawing.Point(496, 243);
            this.txtstadium.Name = "txtstadium";
            this.txtstadium.Size = new System.Drawing.Size(243, 22);
            this.txtstadium.TabIndex = 33;
            // 
            // dtmatch
            // 
            this.dtmatch.Location = new System.Drawing.Point(496, 185);
            this.dtmatch.Name = "dtmatch";
            this.dtmatch.Size = new System.Drawing.Size(243, 22);
            this.dtmatch.TabIndex = 32;
            // 
            // txtt2
            // 
            this.txtt2.Location = new System.Drawing.Point(496, 128);
            this.txtt2.Name = "txtt2";
            this.txtt2.Size = new System.Drawing.Size(243, 22);
            this.txtt2.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(285, 248);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 17);
            this.label3.TabIndex = 30;
            this.label3.Text = "STADIUM";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(285, 185);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 17);
            this.label2.TabIndex = 29;
            this.label2.Text = "DATE OF MATCH";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(285, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 17);
            this.label4.TabIndex = 28;
            this.label4.Text = "TEAM 2";
            // 
            // btnsubmit
            // 
            this.btnsubmit.Location = new System.Drawing.Point(569, 295);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(75, 63);
            this.btnsubmit.TabIndex = 27;
            this.btnsubmit.Text = "UPDATE";
            this.btnsubmit.UseVisualStyleBackColor = true;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // txtt1
            // 
            this.txtt1.Location = new System.Drawing.Point(496, 79);
            this.txtt1.Name = "txtt1";
            this.txtt1.Size = new System.Drawing.Size(243, 22);
            this.txtt1.TabIndex = 26;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(285, 79);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 17);
            this.label5.TabIndex = 25;
            this.label5.Text = "TEAM 1";
            // 
            // Update_Matches
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1140, 588);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txttid);
            this.Controls.Add(this.label1);
            this.Name = "Update_Matches";
            this.Text = "Update_Matches";
            this.Load += new System.EventHandler(this.Update_Matches_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txttid)).EndInit();
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.NumericUpDown txttid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.TextBox txtstadium;
        private System.Windows.Forms.DateTimePicker dtmatch;
        private System.Windows.Forms.TextBox txtt2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.TextBox txtt1;
        private System.Windows.Forms.Label label5;
    }
}