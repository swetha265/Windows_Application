﻿namespace Cricket_Team_Management
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.cOUNTRIESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tEAMSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pLAYERSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mATCHESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cOUNTRIESToolStripMenuItem,
            this.tEAMSToolStripMenuItem,
            this.pLAYERSToolStripMenuItem,
            this.mATCHESToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(938, 28);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // cOUNTRIESToolStripMenuItem
            // 
            this.cOUNTRIESToolStripMenuItem.Name = "cOUNTRIESToolStripMenuItem";
            this.cOUNTRIESToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.cOUNTRIESToolStripMenuItem.Text = "COUNTRIES";
            this.cOUNTRIESToolStripMenuItem.Click += new System.EventHandler(this.cOUNTRIESToolStripMenuItem_Click);
            // 
            // tEAMSToolStripMenuItem
            // 
            this.tEAMSToolStripMenuItem.Name = "tEAMSToolStripMenuItem";
            this.tEAMSToolStripMenuItem.Size = new System.Drawing.Size(68, 24);
            this.tEAMSToolStripMenuItem.Text = "TEAMS";
            this.tEAMSToolStripMenuItem.Click += new System.EventHandler(this.tEAMSToolStripMenuItem_Click);
            // 
            // pLAYERSToolStripMenuItem
            // 
            this.pLAYERSToolStripMenuItem.Name = "pLAYERSToolStripMenuItem";
            this.pLAYERSToolStripMenuItem.Size = new System.Drawing.Size(78, 24);
            this.pLAYERSToolStripMenuItem.Text = "PLAYERS";
            // 
            // mATCHESToolStripMenuItem
            // 
            this.mATCHESToolStripMenuItem.Name = "mATCHESToolStripMenuItem";
            this.mATCHESToolStripMenuItem.Size = new System.Drawing.Size(86, 24);
            this.mATCHESToolStripMenuItem.Text = "MATCHES";
            this.mATCHESToolStripMenuItem.Click += new System.EventHandler(this.mATCHESToolStripMenuItem_Click);
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(938, 421);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Dashboard";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cOUNTRIESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tEAMSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pLAYERSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mATCHESToolStripMenuItem;
    }
}

