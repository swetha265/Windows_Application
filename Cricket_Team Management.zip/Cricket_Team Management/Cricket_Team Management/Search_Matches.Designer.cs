﻿namespace Cricket_Team_Management
{
    partial class Search_Matches
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.txttid = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblt1 = new System.Windows.Forms.Label();
            this.lblt2 = new System.Windows.Forms.Label();
            this.lbldt = new System.Windows.Forms.Label();
            this.lblst = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.txttid)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(709, 85);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(181, 27);
            this.button1.TabIndex = 8;
            this.button1.Text = "SEARCH ID";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txttid
            // 
            this.txttid.Location = new System.Drawing.Point(294, 85);
            this.txttid.Name = "txttid";
            this.txttid.Size = new System.Drawing.Size(224, 22);
            this.txttid.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 87);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "ENTER MATCH ID";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblst);
            this.panel1.Controls.Add(this.lbldt);
            this.panel1.Controls.Add(this.lblt2);
            this.panel1.Controls.Add(this.lblt1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(35, 174);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(916, 237);
            this.panel1.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(398, 194);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 17);
            this.label3.TabIndex = 34;
            this.label3.Text = "STADIUM";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(398, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 17);
            this.label2.TabIndex = 33;
            this.label2.Text = "DATE OF MATCH";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(398, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 17);
            this.label4.TabIndex = 32;
            this.label4.Text = "TEAM 2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(398, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 17);
            this.label5.TabIndex = 31;
            this.label5.Text = "TEAM 1";
            // 
            // lblt1
            // 
            this.lblt1.AutoSize = true;
            this.lblt1.Location = new System.Drawing.Point(553, 25);
            this.lblt1.Name = "lblt1";
            this.lblt1.Size = new System.Drawing.Size(46, 17);
            this.lblt1.TabIndex = 35;
            this.lblt1.Text = "label6";
            // 
            // lblt2
            // 
            this.lblt2.AutoSize = true;
            this.lblt2.Location = new System.Drawing.Point(553, 77);
            this.lblt2.Name = "lblt2";
            this.lblt2.Size = new System.Drawing.Size(46, 17);
            this.lblt2.TabIndex = 36;
            this.lblt2.Text = "label7";
            // 
            // lbldt
            // 
            this.lbldt.AutoSize = true;
            this.lbldt.Location = new System.Drawing.Point(553, 131);
            this.lbldt.Name = "lbldt";
            this.lbldt.Size = new System.Drawing.Size(46, 17);
            this.lbldt.TabIndex = 37;
            this.lbldt.Text = "label8";
            // 
            // lblst
            // 
            this.lblst.AutoSize = true;
            this.lblst.Location = new System.Drawing.Point(553, 194);
            this.lblst.Name = "lblst";
            this.lblst.Size = new System.Drawing.Size(46, 17);
            this.lblst.TabIndex = 38;
            this.lblst.Text = "label9";
            // 
            // Search_Matches
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1013, 442);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txttid);
            this.Controls.Add(this.label1);
            this.Name = "Search_Matches";
            this.Text = "Search_Matches";
            this.Load += new System.EventHandler(this.Search_Matches_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txttid)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.NumericUpDown txttid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblst;
        private System.Windows.Forms.Label lbldt;
        private System.Windows.Forms.Label lblt2;
        private System.Windows.Forms.Label lblt1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}