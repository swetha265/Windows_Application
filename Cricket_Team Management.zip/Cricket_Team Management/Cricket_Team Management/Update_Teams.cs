﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Update_Teams : Form
    {

        SqlConnection conn;
        public Update_Teams()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel.Visible = false;
            string id = txttid.Value.ToString();
            try
            {
                conn.Open();
                string query = "select * from Teams where Team_id=" + id;
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {

                    Teams_Details t = new Teams_Details();
                    t.teamid = int.Parse(reader[0].ToString());
                    t.team_name = reader[1].ToString();
                    t.countryid = int.Parse(reader[2].ToString());
                    panel.Visible = true;
                }
                else
                    MessageBox.Show(" sorry team id does not exist");
                conn.Close();


            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
                
            }
            
        }

            private void Update_Teams_Load(object sender, EventArgs e)
            {
                panel.Visible = false;

            }
            private void updateme(Teams_Details t)
            {
                txttname.Text = t.team_name;
                txtcid.Value = t.countryid;
                panel.Visible = true;
            }

            private void btnupdate_Click(object sender, EventArgs e)
            {
                string query = string.Format("update teams set team_name='{0}',country_id={1}", txttname.Text, txtcid.Value);
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Updated");
                    conn.Close();

                }
                catch (Exception ob)
                {
                    MessageBox.Show("Data cannot be updated \n" + ob.Message);
                }
            }
        }
    }


