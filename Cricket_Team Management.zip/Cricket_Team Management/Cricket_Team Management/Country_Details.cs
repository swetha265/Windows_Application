﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cricket_Team_Management
{
    class Country_Details
    {
        public int country_id { get; set; }
        public string country_name{ get; set; }
        public string country_desc { get; set; }
        public override string ToString()
        {
            string mydata = "";
            mydata += country_id.ToString() + "\n";
            mydata += country_name.ToString() + "\n";
            mydata += country_desc.ToString() + "\n";
            return mydata;
        }



    }
}
