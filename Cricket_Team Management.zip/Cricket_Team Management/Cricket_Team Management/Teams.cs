﻿using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Teams : Form
    {
        public Teams()
        {
            InitializeComponent();
        }

        private void lbladd_Click(object sender, EventArgs e)
        {
            Add_Teams ob = new Add_Teams();
            ob.Show();
            this.Hide();
        }

        private void lbldelete_Click(object sender, EventArgs e)
        {
            DELETE_TEAMS ob = new DELETE_TEAMS();
            ob.Show();
            this.Hide();
        }

        private void lbldisplay_Click(object sender, EventArgs e)
        {
            Display_Teams ob = new Display_Teams();
            ob.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Update_Teams ob = new Update_Teams();
            ob.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Search_Details ob = new Search_Details();
            ob.Show();
            this.Hide();
        }
    }
}
