﻿namespace Cricket_Team_Management
{
    partial class Add_Teams
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblid = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.txttid = new System.Windows.Forms.NumericUpDown();
            this.txttname = new System.Windows.Forms.TextBox();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.lblcid = new System.Windows.Forms.Label();
            this.cmbcid = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.txttid)).BeginInit();
            this.SuspendLayout();
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.Location = new System.Drawing.Point(53, 47);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(63, 17);
            this.lblid.TabIndex = 0;
            this.lblid.Text = "TEAM ID";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(53, 91);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(89, 17);
            this.lblname.TabIndex = 1;
            this.lblname.Text = "TEAM NAME";
            // 
            // txttid
            // 
            this.txttid.Location = new System.Drawing.Point(286, 45);
            this.txttid.Name = "txttid";
            this.txttid.Size = new System.Drawing.Size(185, 22);
            this.txttid.TabIndex = 3;
            // 
            // txttname
            // 
            this.txttname.Location = new System.Drawing.Point(286, 91);
            this.txttname.Name = "txttname";
            this.txttname.Size = new System.Drawing.Size(185, 22);
            this.txttname.TabIndex = 4;
            // 
            // btnsubmit
            // 
            this.btnsubmit.Location = new System.Drawing.Point(286, 203);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(185, 52);
            this.btnsubmit.TabIndex = 6;
            this.btnsubmit.Text = "SUBMIT";
            this.btnsubmit.UseVisualStyleBackColor = true;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // lblcid
            // 
            this.lblcid.AutoSize = true;
            this.lblcid.Location = new System.Drawing.Point(49, 133);
            this.lblcid.Name = "lblcid";
            this.lblcid.Size = new System.Drawing.Size(93, 17);
            this.lblcid.TabIndex = 2;
            this.lblcid.Text = "COUNTRY ID";
            // 
            // cmbcid
            // 
            this.cmbcid.FormattingEnabled = true;
            this.cmbcid.Location = new System.Drawing.Point(286, 148);
            this.cmbcid.Name = "cmbcid";
            this.cmbcid.Size = new System.Drawing.Size(185, 24);
            this.cmbcid.TabIndex = 7;
            // 
            // Add_Teams
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.cmbcid);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.txttname);
            this.Controls.Add(this.txttid);
            this.Controls.Add(this.lblcid);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.lblid);
            this.Name = "Add_Teams";
            this.Text = "Add_Teams";
            this.Load += new System.EventHandler(this.Add_Teams_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txttid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.NumericUpDown txttid;
        private System.Windows.Forms.TextBox txttname;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Label lblcid;
        private System.Windows.Forms.ComboBox cmbcid;
    }
}