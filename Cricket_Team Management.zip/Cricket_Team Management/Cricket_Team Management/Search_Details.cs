﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Search_Details : Form
    {

        SqlConnection conn;
        public Search_Details()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void btnsearch_Click(object sender, EventArgs e)
        { 
      

            panel.Visible = false;
            string id = txttid.Value.ToString();
            try
            {
                conn.Open();
                string sql = "select * from Teams where Team_id=" + id;
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    Teams_Details t = new Teams_Details();
                    t.teamid = int.Parse(reader[0].ToString());
                    t.team_name = reader[1].ToString();
                    t.countryid = int.Parse(reader[2].ToString());
                    lbltname.Text = reader[1].ToString();
                    lblcid.Text = reader[2].ToString();
                    panel.Visible = true;
                }
                else
                    MessageBox.Show("Team id doesnot exist");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show("some issue with connection");
            }
        }

        private void Search_Details_Load(object sender, EventArgs e)
        {
            panel.Visible = false;

        }

    }

}

