﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Search_Matches : Form
    {
        SqlConnection conn;
        public Search_Matches()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            string id = txttid.Value.ToString();
            try
            {
                conn.Open();
                string sql = "select * from matches where match_id=" + id;
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    Match_Details m = new Match_Details();
                    m.match_id = int.Parse(reader[0].ToString());
                    m.team1 = reader[1].ToString();
                    m.team2 = reader[2].ToString();
                    m.date_of_match = reader[3].ToString();
                    m.stadium_name = reader[4].ToString();
                    lblt1.Text = reader[1].ToString();
                    lblt2.Text = reader[2].ToString();
                    lbldt.Text = reader[3].ToString();
                    lblst.Text = reader[4].ToString();
                    panel1.Visible = true;
                }
                else
                    MessageBox.Show("match id doesnot exist");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show("some issue with connection");
            }

        }

        private void Search_Matches_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }
    }
}
