﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Update_Matches : Form
    {
        SqlConnection conn;
        public Update_Matches()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel.Visible = false;
            string id = txttid.Value.ToString();
            try
            {
                conn.Open();
                string query = "select * from matches where match_id=" + id;
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {

                    Match_Details m = new Match_Details();
                    m.match_id = int.Parse(reader[0].ToString());
                    m.team1 = reader[1].ToString();
                    m.team2 = reader[2].ToString();
                    m.date_of_match = reader[3].ToString();
                    m.stadium_name = reader[4].ToString();
                    panel.Visible = true;
                }
                else
                    MessageBox.Show(" sorry match id does not exist");
                conn.Close();


            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);

            }

        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            panel.Visible = false;

        }
        private void updateme(Match_Details t)
        {
            
            txtt1.Text = t.team1;
            txtt2.Text = t.team2;
            dtmatch.Text = t.date_of_match;
            txtstadium.Text = t.stadium_name;
          
            panel.Visible = true;
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            string query = string.Format("update matches set team1='{0}',team2='{1}', date_of_match='{2}', stadium_name='{3}'", txtt1.Text, txtt2.Text, dtmatch.Text, txtstadium.Text);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated");
                conn.Close();

            }
            catch (Exception ob)
            {
                MessageBox.Show("Data cannot be updated \n" + ob.Message);
            }
        }

        private void Update_Matches_Load(object sender, EventArgs e)
        {
            panel.Visible = false;
        }
    }
}
