﻿namespace Cricket_Team_Management
{
    partial class Display_Teams
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgteamsdisplay = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgteamsdisplay)).BeginInit();
            this.SuspendLayout();
            // 
            // dgteamsdisplay
            // 
            this.dgteamsdisplay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgteamsdisplay.Location = new System.Drawing.Point(110, 76);
            this.dgteamsdisplay.Name = "dgteamsdisplay";
            this.dgteamsdisplay.RowTemplate.Height = 24;
            this.dgteamsdisplay.Size = new System.Drawing.Size(518, 198);
            this.dgteamsdisplay.TabIndex = 0;
            this.dgteamsdisplay.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Display_Teams
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgteamsdisplay);
            this.Name = "Display_Teams";
            this.Text = "Display_Teams";
            this.Load += new System.EventHandler(this.Display_Teams_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgteamsdisplay)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgteamsdisplay;
    }
}