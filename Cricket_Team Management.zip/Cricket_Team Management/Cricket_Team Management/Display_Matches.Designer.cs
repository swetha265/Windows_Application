﻿namespace Cricket_Team_Management
{
    partial class Display_Matches
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgmdisplay = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgmdisplay)).BeginInit();
            this.SuspendLayout();
            // 
            // dgmdisplay
            // 
            this.dgmdisplay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgmdisplay.Location = new System.Drawing.Point(85, 74);
            this.dgmdisplay.Name = "dgmdisplay";
            this.dgmdisplay.RowTemplate.Height = 24;
            this.dgmdisplay.Size = new System.Drawing.Size(612, 207);
            this.dgmdisplay.TabIndex = 1;
            // 
            // Display_Matches
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dgmdisplay);
            this.Name = "Display_Matches";
            this.Text = "Display_Matches";
            this.Load += new System.EventHandler(this.Display_Matches_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgmdisplay)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgmdisplay;
    }
}