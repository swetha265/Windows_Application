﻿namespace Cricket_Team_Management
{
    partial class Matches
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbldisplay = new System.Windows.Forms.Label();
            this.lbldelete = new System.Windows.Forms.Label();
            this.lbladd = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 232);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = "SEARCH MATCHES";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 182);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 17);
            this.label1.TabIndex = 11;
            this.label1.Text = "UPDATE MATCHES";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbldisplay
            // 
            this.lbldisplay.AutoSize = true;
            this.lbldisplay.Location = new System.Drawing.Point(57, 132);
            this.lbldisplay.Name = "lbldisplay";
            this.lbldisplay.Size = new System.Drawing.Size(135, 17);
            this.lbldisplay.TabIndex = 10;
            this.lbldisplay.Text = "DISPLAY MATCHES";
            this.lbldisplay.Click += new System.EventHandler(this.lbldisplay_Click);
            // 
            // lbldelete
            // 
            this.lbldelete.AutoSize = true;
            this.lbldelete.Location = new System.Drawing.Point(57, 83);
            this.lbldelete.Name = "lbldelete";
            this.lbldelete.Size = new System.Drawing.Size(132, 17);
            this.lbldelete.TabIndex = 9;
            this.lbldelete.Text = "DELETE MATCHES";
            this.lbldelete.Click += new System.EventHandler(this.lbldelete_Click);
            // 
            // lbladd
            // 
            this.lbladd.AutoSize = true;
            this.lbladd.Location = new System.Drawing.Point(57, 39);
            this.lbladd.Name = "lbladd";
            this.lbladd.Size = new System.Drawing.Size(107, 17);
            this.lbladd.TabIndex = 8;
            this.lbladd.Text = "ADD MATCHES";
            this.lbladd.Click += new System.EventHandler(this.lbladd_Click);
            // 
            // Matches
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbldisplay);
            this.Controls.Add(this.lbldelete);
            this.Controls.Add(this.lbladd);
            this.Name = "Matches";
            this.Text = "Matches";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbldisplay;
        private System.Windows.Forms.Label lbldelete;
        private System.Windows.Forms.Label lbladd;
    }
}