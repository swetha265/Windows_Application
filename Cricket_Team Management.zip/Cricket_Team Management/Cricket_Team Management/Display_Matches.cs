﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Display_Matches : Form
    {
        SqlConnection conn;
        public Display_Matches()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void Display_Matches_Load(object sender, EventArgs e)
        {
            string query = "select * from matches ";
            List<Match_Details> t = new List<Match_Details>();

            try
            {
                conn.Open();

                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataSet ds = new DataSet("mydetails");
                da.Fill(ds);
                dgmdisplay.DataSource = ds.Tables[0];
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }

        }
    }
}
