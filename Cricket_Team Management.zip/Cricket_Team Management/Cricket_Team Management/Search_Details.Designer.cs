﻿namespace Cricket_Team_Management
{
    partial class Search_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnsearch = new System.Windows.Forms.Button();
            this.txttid = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.panel = new System.Windows.Forms.Panel();
            this.lblcid = new System.Windows.Forms.Label();
            this.lbltname = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.txttid)).BeginInit();
            this.panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(505, 73);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(181, 27);
            this.btnsearch.TabIndex = 5;
            this.btnsearch.Text = "SEARCH ID";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // txttid
            // 
            this.txttid.Location = new System.Drawing.Point(252, 78);
            this.txttid.Name = "txttid";
            this.txttid.Size = new System.Drawing.Size(162, 22);
            this.txttid.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "ENTER TEAM ID";
            // 
            // panel
            // 
            this.panel.Controls.Add(this.lblcid);
            this.panel.Controls.Add(this.lbltname);
            this.panel.Controls.Add(this.label2);
            this.panel.Controls.Add(this.label3);
            this.panel.Location = new System.Drawing.Point(75, 166);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(651, 265);
            this.panel.TabIndex = 6;
          
            // 
            // lblcid
            // 
            this.lblcid.AutoSize = true;
            this.lblcid.Location = new System.Drawing.Point(280, 97);
            this.lblcid.Name = "lblcid";
            this.lblcid.Size = new System.Drawing.Size(46, 17);
            this.lblcid.TabIndex = 15;
            this.lblcid.Text = "label5";
            // 
            // lbltname
            // 
            this.lbltname.AutoSize = true;
            this.lbltname.Location = new System.Drawing.Point(280, 34);
            this.lbltname.Name = "lbltname";
            this.lbltname.Size = new System.Drawing.Size(46, 17);
            this.lbltname.TabIndex = 14;
            this.lbltname.Text = "label4";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(130, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 17);
            this.label2.TabIndex = 13;
            this.label2.Text = "TEAM NAME";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(130, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "COUNTRY ID";
            // 
            // Search_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.txttid);
            this.Controls.Add(this.label1);
            this.Name = "Search_Details";
            this.Text = "Search_Details";
            this.Load += new System.EventHandler(this.Search_Details_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txttid)).EndInit();
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.NumericUpDown txttid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.Label lblcid;
        private System.Windows.Forms.Label lbltname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}